package ar.org.centro35.curso.java.clase02;
public class Clase02{
    public static void main(String[] args) {
        //Punto de entrada al proyecto
        System.out.println("Hola Mundo!!");

        System.out.println("-- auto1 --");
        Auto auto1=new Auto();      //new Auto(); construir un objeto de la clase
        auto1.marca="Fiat";
        auto1.modelo="Idea";
        auto1.color="Rojo";
        auto1.acelerar();           // 10
        auto1.acelerar();           // 20
        auto1.acelerar();           // 30
        auto1.frenar();             // 20
        auto1.acelerar(25);     // 45
        System.out.println(auto1.marca+", "+auto1.modelo+", "+auto1.color+", "+auto1.velocidad);
        //Los atributos numericos se inicializan automaticamente en 0
        //Los atributos String se inicializan automáticamente en null

        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Ford";
        auto2.modelo="Ka";
        auto2.color="Negro";
        for(int a=0;a<=65; a++) auto2.acelerar();
        System.out.println(auto2.marca+", "+auto2.modelo+", "+auto2.color+", "+auto2.velocidad);
        System.out.println("Velocidad: "+auto2.obtenerVelocidad());

        System.out.println("-- auto3 --");
        Auto auto3=new Auto("Fiat","Uno","Blanco");
        System.out.println(auto3.toString());
        System.out.println(auto3);


    }
}