package ar.org.centro35.curso.java.clase02;

//Declaración de clases
public class Auto {
    
    //atributos
    String marca;
    String modelo;
    String color;
    int velocidad;
    
    //método constructor
    Auto(){} //constructor vacio

    Auto(String marca, String modelo, String color){
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
    }

    //métodos
    void acelerar(){
        velocidad+=10;
        if(velocidad>100) velocidad=100;        //regla de negocio
    }

    //Sobrecarga de métodos
    //Método con parámetro de entrada
    void acelerar(int kilometros){
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100;
    }

    void frenar(){
        velocidad-=10;
    }

    //método con devolución de valor
    int obtenerVelocidad(){
        return velocidad;
    }

    //método toString()
    @Override                   // Annotation JDK5 o sup
    public String toString(){
        return marca+", "+modelo+", "+color;
    }

}//end class
