package ar.org.centro35.curso.java.test;

import ar.org.centro35.curso.java.entity.Empleado;

public class TestEmpleado {
    public static void main(String[] args) {
        //Test Objetos Mocks (Objetos Simulados)

        Empleado empleado1=new Empleado(1, "Nilda", "Alvarez", 345000);
        //empleado1.sueldoBasico=900000000;
        empleado1.setSueldoBasico(900000000);
        System.out.println(empleado1);

    }
}
