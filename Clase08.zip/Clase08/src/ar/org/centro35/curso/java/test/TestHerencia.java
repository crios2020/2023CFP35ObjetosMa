package ar.org.centro35.curso.java.test;

import ar.org.centro35.curso.java.entitities.Cliente;
import ar.org.centro35.curso.java.entitities.Cuenta;
import ar.org.centro35.curso.java.entitities.Direccion;
import ar.org.centro35.curso.java.entitities.Persona;
import ar.org.centro35.curso.java.entitities.Vendedor;

public class TestHerencia {
	public static void main(String[] args) {
		// Test Herencia
		
		System.out.println("-- direccion1 --");
		Direccion direccion1=new Direccion("Lima",222,"4","e");
		System.out.println(direccion1);
		
		System.out.println("-- direccion2 --");
		Direccion direccion2=new Direccion("Belgrano",49,null,null,"Morón");
		System.out.println(direccion2);
		
		System.out.println("-- cuenta1 --");
		Cuenta cuenta1=new Cuenta(1,"arg$");
		cuenta1.depositar(80000);
		cuenta1.debitar(5000);
		System.out.println(cuenta1);
		
		System.out.println("-- persona1 --");
		Persona persona1=new Persona("David",23,direccion1);
		System.out.println(persona1);
		persona1.saludar();
		
		System.out.println("-- vendedor1 --");
		Vendedor vendedor1=new Vendedor("Valeria",36,direccion2,1,500000);
		System.out.println(vendedor1);
		vendedor1.saludar();
		
		System.out.println("-- cliente1 --");
		Cliente cliente1=new Cliente("Mariela",45,direccion1,1,cuenta1);
		cliente1.getCuenta().depositar(60000);
		System.out.println(cliente1);
		cliente1.saludar();
		
	}
}
