package ar.org.centro35.curso.java.test;

import ar.org.centro35.curso.java.entity.ClienteEmpresa;
import ar.org.centro35.curso.java.entity.ClientePersona;
import ar.org.centro35.curso.java.entity.Cuenta;

public class TestRelaciones {
    public static void main(String[] args) {
        System.out.println("Test Relaciones");

        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1, "args");
        cuenta1.depositar(400000);
        cuenta1.depositar(550000);
        cuenta1.debitar(180000);
        System.out.println(cuenta1);


        System.out.println("-- clientePersona1 --");
        ClientePersona clientePersona1=new ClientePersona(
                                        1,
                                        "Andrea Moretti",
                                        49, 
                                        new Cuenta(2,"args"));
        clientePersona1.getCuenta().depositar(500000);
        System.out.println(clientePersona1);

        System.out.println("-- clientePersona2 --");
        ClientePersona clientePersona2=new ClientePersona(
                            2,
                            "Silvio Contretas", 
                            52, 
                            clientePersona1.getCuenta());
        clientePersona2.getCuenta().debitar(200000);
        System.out.println(clientePersona2);
        System.out.println(clientePersona1);

        System.out.println("-- clientePersona3 --");
        ClientePersona clientePersona3=new ClientePersona(
                            3, 
                            "Cristian Molina", 
                            36, 
                            3, 
                            "Args");                

        clientePersona3.getCuenta().depositar(750000);
        System.out.println(clientePersona3);

        System.out.println("-- clienteEmpresa1 --");
        ClienteEmpresa clienteEmpresa1= new ClienteEmpresa(
                                    1,
                                    "Los mecanicos",
                                    "Los Toldos 232");

        clienteEmpresa1.getCuentas().add(new Cuenta(10, "args"));       // 0 
        clienteEmpresa1.getCuentas().add(new Cuenta(11, "reales"));     // 1
        clienteEmpresa1.getCuentas().add(new Cuenta(12, "U$S"));        // 2

        clienteEmpresa1.getCuentas().get(0).depositar(450000);
        clienteEmpresa1.getCuentas().get(1).depositar(100000);
        clienteEmpresa1.getCuentas().get(2).depositar(10000);

        System.out.println(clienteEmpresa1);
        //TODO usar Eclipse

    }
}
